// JavaScript functions to show and hide the menu
function showMenu() {
  const menu = document.querySelector('.menu');
  menu.style.display = 'block';
}

function hideMenu() {
  const menu = document.querySelector('.menu');
  menu.style.display = 'none';
}

function signIn() {
  // Add your sign-in logic here
  console.log('Sign-in button clicked');
  // Add further actions like redirecting to a sign-in page, displaying a form, etc.
}

document.getElementById('salesButton').addEventListener('click', contactSales);

    function contactSales() {
      // Replace this with your contact sales logic
      console.log('Contact Sales button clicked');
      
      window.open('https://example.com/contact-form', '_blank'); // Opens a contact form in a new tab

      // Example: Display a message to the user
      alert('Thank you for contacting sales! We will get in touch with you shortly.');

      // Example: Perform other sales-related actions like sending an email, etc.
      // Your specific sales-related actions can be implemented here
    }


    document.addEventListener('DOMContentLoaded', function() {
      // Get the element by its class name
      var startForFreeButton = document.querySelector('.frame-227-4Ks');

      // Add a click event listener to the element
      startForFreeButton.addEventListener('click', function() {
        // Your action when the element is clicked
        alert('Start For Free clicked! Redirecting to sign-up page...');
        // logic here, such as redirecting to a sign-up page:
        // window.location.href = 'signup.html'; // Replace 'signup.html' with your signup page URL
      });
    });

    document.addEventListener('DOMContentLoaded', function() {
      // Get the element by its class name
      var contactSalesButton = document.querySelector('.frame-227-t9f button');

      // Add a click event listener to the button
      contactSalesButton.addEventListener('click', function() {
        // Your action when the button is clicked
        alert('Contact Sales button clicked! Redirecting to contact page...');
        // Redirect to a contact page upon button click
        window.location.href = 'contact.html'; // Replace 'contact.html' with your contact page URL
      });
    });

    document.addEventListener('DOMContentLoaded', function() {
      // Get the element by its class name
      var startForFreeButton = document.querySelector('.frame-67-zmf button');

      // Add a click event listener to the button
      startForFreeButton.addEventListener('click', function() {
        // Your action when the button is clicked
        // Replace this line with your desired action
        window.location.href = 'https://example.com'; // Replace 'https://example.com' with your desired URL
      });
    
      
      function openSocialMedia(url) {
        window.open(url);
    }